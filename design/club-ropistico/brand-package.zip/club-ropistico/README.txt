Original artwork and concept application mockups.
Website assets are optimized by Astro; these PNGs retain the full output resolution.
The color values are sampled from the supplied original artwork.
